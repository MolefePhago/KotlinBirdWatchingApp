package com.example.birdview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import com.example.birdview.databinding.ActivityFullMapBinding
import com.mapbox.maps.MapView
import com.mapbox.maps.Style
import com.example.birdview.databinding.ActivityFullMapBinding
import com.mapbox.android.core.location.LocationEngine
import com.mapbox.android.core.location.LocationEngineProvider
import com.mapbox.android.core.location.LocationEngineRequest
import com.mapbox.android.core.location.LocationEngineCallback
import com.mapbox.android.core.location.LocationEngineResult
import com.mapbox.geojson.Point
import com.mapbox.mapboxsdk.maps.MapboxMap
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback
import com.mapbox.mapboxsdk.plugins.annotation.SymbolManager
import com.mapbox.mapboxsdk.plugins.annotation.SymbolOptions

class FullMap : AppCompatActivity() {
    private lateinit var binding: ActivityFullMapBinding
    lateinit var toggle: ActionBarDrawerToggle
    var mapView: MapView? = null
    private var mapboxMap: MapboxMap? = null
    private var symbolManager: SymbolManager? = null
    private var userLocation: Point? = null
    private var birdLocation: Point? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFullMapBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mapView = binding.mapView
        //mapView?.getMapboxMap()?.loadStyleUri(Style.MAPBOX_STREETS)
        mapView?.onCreate(savedInstanceState)

        //This code is for the side bar
        toggle = ActionBarDrawerToggle(this@FullMap, binding.drawerLayouts, 0, 0)
        binding.drawerLayouts.addDrawerListener(toggle)
        toggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.navViews.setNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.Map -> {
                    val map = Intent(this, FullMap::class.java)
                    startActivity(map)
                }
                R.id.Entry -> {
                    val entry = Intent(this, BirdEntry::class.java)
                    startActivity(entry)
                }
                R.id.Category ->{
                    val category = Intent(this, SpecieCatgeory::class.java)
                    startActivity(category)
                }
                R.id.logout -> Toast.makeText(applicationContext, "cghj", Toast.LENGTH_SHORT).show()
            }
            true

        }
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (toggle.onOptionsItemSelected(item)) {
            true
        }
        return super.onOptionsItemSelected(item)

    }*/
        // Style of th map loaded

        mapView?.getMapboxMapAsync(object : OnMapReadyCallback {
            override fun onMapReady(mapboxMap: MapboxMap) {
                FullMap.this.mapboxMap = mapboxMap
                mapboxMap.setStyle(Style.MAPBOX_STREETS) {
                }

                // Initialize SymbolManager for adding markers
                symbolManager = SymbolManager(mapView, mapboxMap, it)
                symbolManager?.iconAllowOverlap = true
                symbolManager?.iconIgnorePlacement = true

                // Hardcoding user and Birdlocation for testing
                userLocation = Point.fromLngLat(-122.4194, 37.7749)
                birdLocation = Point.fromLngLat(-122.4082, 37.7562)

                // This code is for calculating the distance of the bird
                val distance = calculateDistance(userLocation, birdLocation)
                Toast.makeText(
                    applicationContext,
                    "Distance to bird: $distance meters",
                    Toast.LENGTH_SHORT
                ).show()

                // Add markers for user and bird locations.NB:("user-icon") can be replace with the actual user icon
                // Same as the Bird icon
                symbolManager?.create(
                    SymbolOptions()
                        .withLatLng(userLocation)
                        .withIconImage("user-icon")
                )
                symbolManager?.create(
                    SymbolOptions()
                        .withLatLng(birdLocation)
                        .withIconImage("bird-icon")
                )
            }
        })

        // Initialize location engine and request location updates
        val locationEngine: LocationEngine = LocationEngineProvider.getBestLocationEngine(this)
        val request = LocationEngineRequest.Builder(1000) // Interval in milliseconds
            .setPriority(LocationEngineRequest.PRIORITY_HIGH_ACCURACY)
            .build()

        val callback = object : LocationEngineCallback<LocationEngineResult> {
            override fun onSuccess(result: LocationEngineResult?) {
                result?.lastLocation?.let { location ->
                    // Update userLocation with the latest location data
                    userLocation = Point.fromLngLat(location.longitude, location.latitude)
                    // Recalculate and update the distance
                    val distance = calculateDistance(userLocation, birdLocation)
                    Toast.makeText(
                        applicationContext,
                        "Distance to bird: $distance meters",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            // This will control error that comes with the location
            override fun onFailure(exception: Exception) {
            }
        }
        // This line is responsible for requesting location updates from the location engine
        locationEngine.requestLocationUpdates(request, callback, mainLooper)
    }

    //Calculatingthe distance between the user's location and the bird's
    private fun calculateDistance(point1: Point?, point2: Point?): Double {
        if (point1 == null || point2 == null) {
            return 0.0
        }
        return point1.distanceTo(point2)
    }

    override fun onStart() {
        super.onStart()
        mapView?.onStart()
    }

    override fun onResume() {
        super.onResume()
        mapView?.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView?.onPause()
    }

    override fun onStop() {
        super.onStop()
        mapView?.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView?.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView?.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView?.onLowMemory()
    }

}
        // This is as far as i could go for the prsentation